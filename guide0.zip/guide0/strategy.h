#ifndef STRATEGY_H
#define STRATEGY_H

#define INF INT_MAX - 1

#include "mymap.h"
#include <QDebug>
#include <QString>
#include <QTextStream>
#include <QVector>

struct Nav_node {
  QString name;
  map_node *cur_node;
  map_arc * cur_arc;
  struct Nav_node *next_node;
};
typedef Nav_node nav_node;

class strategy {
public:
  strategy();

  void clearStra(map_node *head); //使地图中的strategy归零
  nav_node *
  Min_dis_str(map_node *head, int count, map_node *begin, map_node *end,
              QVector<map_node *> loc_node); //最短路径算法 使用dijkstra
  nav_node *
  Min_time_str(map_node *head, int count, map_node *begin, map_node *end,
               QVector<map_node *> loc_node); //最短时间算法 使用dijkstra
 static  nav_node *Min_weight_str(map_node *head, int count, map_node *begin,
                           map_node *end, QVector<map_node *>const  &loc_node);
  nav_node *Min_with_transport(map_node *head, int count, map_node *begin,
                               map_node *end, QVector<map_node *> const &loc_node);
static  map_node *dij_find_next_node(map_node *head);
  map_node *find_sur(); //小诗写的bfs，查找周边
  void show_strategy_path(nav_node *head);
  void delete_strategy_path(nav_node *head);
};

#endif // STRATEGY_H
